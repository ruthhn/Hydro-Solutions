ReadMe file:

This website contains information about the project business Hydro Solutions.  We sovle enviromental problems by turning waste into energy.  This website is avalible on all search engines.  Our website includes the following: HTML, CSS, and JavaScript.  There are no bug problems.  This website is owned by Neeley H and Liam O and reserve all rights to these documents.